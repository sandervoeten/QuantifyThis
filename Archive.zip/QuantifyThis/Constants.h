//
//  Constants.h
//  QuantifyThis
//
//  Created by Nik Torfs on 25/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject

extern NSString *const YAHOO_APP_ID;
extern NSString *const YAHOO_WEATHER_DEGREE_UNIT;

@end
