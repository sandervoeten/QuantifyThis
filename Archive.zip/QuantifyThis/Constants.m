//
//  Constants.m
//  QuantifyThis
//
//  Created by Nik Torfs on 25/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import "Constants.h"

@implementation Constants

NSString *const YAHOO_APP_ID = @"dj0yJmk9OTFZSWlwM29rWVRFJmQ9WVdrOWVYQnNVMUZoTjJrbWNHbzlOakV4TnpNMk9UWXkmcz1jb25zdW1lcnNlY3JldCZ4PTky";
NSString *const YAHOO_WEATHER_DEGREE_UNIT = @"c";
@end
