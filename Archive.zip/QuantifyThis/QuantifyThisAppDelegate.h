//
//  QuantifyThisAppDelegate.h
//  QuantifyThis
//
//  Created by Nik Torfs on 11/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuantifyThisAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
