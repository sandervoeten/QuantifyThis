//
//  RegisterMoodModel.h
//  QuantifyThis
//
//  Created by Nik Torfs on 23/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RegisterMoodModel : NSObject


@property NSUInteger *beatsPerMinute;
@property NSUInteger *sleepTime;
@property NSUInteger *sleepQuality;

@end
