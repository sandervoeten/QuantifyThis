//
//  RegisterMoodModel.m
//  QuantifyThis
//
//  Created by Nik Torfs on 23/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import "RegisterMoodModel.h"

@implementation RegisterMoodModel

@synthesize sleepTime = _sleepTime;
@synthesize sleepQuality = _sleepQuality;
@synthesize beatsPerMinute = _beatsPerMinute;

@end
