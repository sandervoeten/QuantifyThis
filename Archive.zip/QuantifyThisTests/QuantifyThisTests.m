//
//  QuantifyThisTests.m
//  QuantifyThisTests
//
//  Created by Nik Torfs on 11/10/12.
//  Copyright (c) 2012 KULeuven. All rights reserved.
//

#import "QuantifyThisTests.h"

@implementation QuantifyThisTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in QuantifyThisTests");
}

@end
